"""Numerical checks for the identities used in ReshufflingHorizon_v1.

The script uses only NumPy and the Python standard library.  It checks both
even and odd component counts, with the paper's pre-update averaging index.
"""

from __future__ import annotations

import itertools
import math

import numpy as np


def signs(n: int) -> np.ndarray:
    half = n // 2
    values = [-1.0] * half + [1.0] * half
    if n % 2:
        values.append(0.0)
    s = np.asarray(values)
    return s / math.sqrt(np.mean(s * s))


def run_quadratic(
    s: np.ndarray,
    eta: float,
    ell: float,
    epochs: list[np.ndarray],
) -> tuple[float, float]:
    x = 0.0
    pre = []
    for permutation in epochs:
        for index in permutation:
            pre.append(x)
            x = (1.0 - eta * ell) * x - eta * s[index]
    return float(np.mean(pre)), x


def exact_quadratic_risk(n: int, k: int, eta: float, ell: float) -> float:
    q = 1.0 - eta * ell
    r = q**n
    weights = q ** np.arange(n - 1, -1, -1)
    variance_weights = float(np.sum((weights - np.mean(weights)) ** 2))
    geometric = (1.0 - r ** (2 * k)) / (1.0 - r**2)
    return variance_weights * geometric / (2.0 * ell * n * (n - 1) * k**2)


def check_bridge_area(n: int, eta: float) -> tuple[float, float]:
    s = signs(n)
    areas = []
    for permutation in itertools.permutations(range(n)):
        prefix = 0.0
        path = []
        for index in permutation:
            path.append(-eta * prefix)
            prefix += s[index]
        areas.append(float(np.mean(path)))
    empirical = float(np.mean(np.square(areas)))
    theory = eta**2 * (n + 1) / 12.0
    return empirical, theory


def check_quadratic(
    n: int,
    k: int,
    eta: float,
    ell: float,
    trials: int,
    seed: int,
) -> tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    s = signs(n)
    risks = []
    telescoping_errors = []
    for _ in range(trials):
        epochs = [rng.permutation(n) for _ in range(k)]
        average, endpoint = run_quadratic(s, eta, ell, epochs)
        telescoping_errors.append(abs(average + endpoint / (eta * ell * n * k)))
        risks.append(0.5 * ell * average**2)
    return (
        float(np.mean(risks)),
        exact_quadratic_risk(n, k, eta, ell),
        max(telescoping_errors),
    )


def check_rectifier_comparison(
    n: int,
    eta: float,
    ell: float,
    trials: int,
    seed: int,
) -> float:
    rng = np.random.default_rng(seed)
    s = signs(n)
    mu = ell / 2415.0
    minimum_gap = math.inf
    for _ in range(trials):
        order = rng.permutation(n)
        rectified = float(rng.normal())
        quadratic = rectified
        for index in order:
            curvature = ell if rectified < 0.0 else mu
            rectified = rectified - eta * (curvature * rectified + s[index])
            quadratic = quadratic - eta * (ell * quadratic + s[index])
            minimum_gap = min(minimum_gap, rectified - quadratic)
    return minimum_gap


def main() -> None:
    for n in (6, 7):
        empirical, theory = check_bridge_area(n, eta=0.017)
        print(
            f"bridge n={n}: empirical={empirical:.15e}, "
            f"theory={theory:.15e}, abs_error={abs(empirical-theory):.3e}"
        )

    for n in (8, 9):
        empirical, theory, telescope = check_quadratic(
            n=n,
            k=11,
            eta=0.004,
            ell=1.0,
            trials=100_000,
            seed=20270806 + n,
        )
        relative = abs(empirical - theory) / theory
        print(
            f"quadratic n={n}: empirical={empirical:.15e}, "
            f"theory={theory:.15e}, relative_error={relative:.3e}, "
            f"max_telescoping_error={telescope:.3e}"
        )

    comparison = check_rectifier_comparison(
        n=17,
        eta=2.0e-4,
        ell=1.0,
        trials=100_000,
        seed=20270823,
    )
    print(f"rectifier pathwise minimum gap={comparison:.3e}")
    assert comparison >= -1.0e-12


if __name__ == "__main__":
    main()
