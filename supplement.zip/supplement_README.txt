Verification supplement for "The Missing Horizon in Random Reshuffling"

Contents
  verify_identities.py      Seeded checks of the reset-bridge constant,
                            all-inner telescoping identity, exact quadratic
                            risk, and rectifier pathwise comparison.
  verification_output.txt  Saved output from Python 3.13.4 and NumPy 2.3.0.

Run
  python verify_identities.py

The script uses only NumPy and the Python standard library. It requires about
32 seconds on a four-core laptop. No data, network access, GPU, or specialized
hardware is required.
